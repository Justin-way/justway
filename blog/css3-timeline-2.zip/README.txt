A Pen created at CodePen.io. You can find this one at http://codepen.io/krishnab/pen/OPwqbW.

 Fully responsive mobile first CSS Timeline.